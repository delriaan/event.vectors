# ![book](network.png) Event Vectors: A temporal framework

## Overview

Package `event.vectors` provides a framework for capturing the relationships among points in time as well as events having duration.  Some definitions should be kept in mind to understand the event vector framework:

- `Vector`: A vector numerically encodes magnitude and direction.

- `Event`: Theoretically, an instantaneous point in time associated with a change of state.  Practically, an event is temporal duration encoded as a pair of temporal points. This is the understanding used in `event.vectors`.

The vector central to `event.vectors` is a complex vector that concisely describes various temporal relations between events.  The entire framework lends itself to temporal graph constructs in addition to tabular representations.  This allows for execution of queries and statistical analysis against the dataset.

**Note**: Parallelism is supported by imports from the [furrr](https://www.rdocumentation.org/packages/furrr) package.  Scalability and parallelism plans have undergone limited testing.

## Installation

Use `remotes::install_github("delriaan/event.vectors", subdir = "pkg")` to install.
